// script.js

document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('taskInput');
    const addTaskButton = document.getElementById('addTaskButton');
    const taskList = document.getElementById('taskList');

    // Function to add a new task
    function addTask() {
        const taskText = taskInput.value.trim();
        if (taskText !== '') {
            const li = document.createElement('li');

            const span = document.createElement('span');
            span.textContent = taskText;

            const actions = document.createElement('div');
            actions.className = 'actions';

            const editButton = document.createElement('button');
            editButton.className = 'edit-btn';
            editButton.textContent = 'Edit';
            editButton.addEventListener('click', () => editTask(li));

            const completeButton = document.createElement('button');
            completeButton.className = 'complete-btn';
            completeButton.textContent = 'Complete';
            completeButton.addEventListener('click', () => toggleCompleteTask(li));

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.addEventListener('click', () => removeTask(li));

            actions.appendChild(editButton);
            actions.appendChild(completeButton);
            actions.appendChild(deleteButton);

            li.appendChild(span);
            li.appendChild(actions);

            taskList.appendChild(li);
            taskInput.value = '';
        }
    }

    // Function to remove a task
    function removeTask(taskElement) {
        taskList.removeChild(taskElement);
    }

    // Function to toggle the completion of a task
    function toggleCompleteTask(taskElement) {
        taskElement.classList.toggle('completed');
    }

    // Function to edit a task
    function editTask(taskElement) {
        const span = taskElement.querySelector('span');
        const newTaskText = prompt('Edit your task:', span.textContent);
        if (newTaskText !== null && newTaskText.trim() !== '') {
            span.textContent = newTaskText.trim();
        }
    }

    // Event listener for the Add Task button
    addTaskButton.addEventListener('click', addTask);

    // Allow adding tasks by pressing Enter key
    taskInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            addTask();
        }
    });
});
